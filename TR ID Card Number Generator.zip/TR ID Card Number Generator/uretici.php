<?php
$sayi1 = rand(1,9);
$sayi2 = rand(1,9);
$sayi3 = rand(1,9);
$sayi4 = rand(1,9);
$sayi5 = rand(1,9);
$sayi6 = rand(1,9);
$sayi7 = rand(1,9);
$sayi8 = rand(1,9);
$sayi9 = rand(1,9);

$dokuzda5 = $sayi1.$sayi2.$sayi3.$sayi4.$sayi5;
$dokuzda4 = $sayi6.$sayi7.$sayi8.$sayi9;
$alticikar = "6";
$ikiekle = "2";

$ilk = $dokuzda5-$alticikar;
$iki = $dokuzda4+$ikiekle;

$ilkdokuzhane = $ilk.$iki;

$dokuzutopla = $sayi1+$sayi2+$sayi3+$sayi4+$sayi5+$sayi6+$sayi7+$sayi8+$sayi9;
$dokuzdankalan = $dokuzutopla%10;
$onuncuhane = $dokuzdankalan;
$onbirincihane = $sayi1+$sayi2+$sayi3+$sayi4+$sayi5+$sayi6+$sayi7+$sayi8+$sayi9+$onuncuhane;


$uretilen=$ilkdokuzhane.$onuncuhane.$onbirincihane;
echo $uretilen;
?>