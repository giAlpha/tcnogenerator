<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<style>
body {
    font-family: sans-serif;
	color:#fff;
	background-color:#000;
}
.wrap {
    width: 75%;
    max-width: 800px;
    margin: 2em auto;
}
img {
    width: 100%;
    border: none;
}
pre {
    overflow: auto;
    padding: 1em;
    border: 1px solid #999;
}
input[type="text"]{
	height:30px;
	min-width:300px;
}
input[type="submit"]{
	height:30px;
	min-width:300px;
	cursor:pointer;
}
#uretilen{
	background-color:#000;
	color:#fff;
	border:1px solid #fff;
	height:30px;
	min-width:300px;
	text-align:center;
	padding-top:5px;
	font-size:25px;
	border-radius:5px;
	}
</style>
<title>TR ID Card Number Generator</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
		$('document').ready(function(){
			$("#uretilen").load("uretici.php");
			$('#uret').click(function(){
					$("#uretilen").load("uretici.php");
			});
		});
</script>
</head>
<body>
<div class="wrap">
<h1>giAlpha TR ID Card Generator</h1>
<p></p>
<table>
	<tr>
		<td>
			<div id="uretilen">54161</div>
		</td>
	</tr>
	<tr>
		<td>
			<input type="submit" class="uret" id="uret" value="ÜRET!" />
		</td>
	</tr>
</table>
</div>
</body>
<script src="responsive-enhance.js"></script>
<script>
responsiveEnhance(document.getElementById('demo1'), 400);
responsiveEnhance(document.getElementById('demo2'), 240);
</script>
</html>